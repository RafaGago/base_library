return {
	"_preload.lua",
	"xcode.lua",
	"xcode4_workspace.lua",
	"xcode_common.lua",
	"xcode_project.lua",
}
